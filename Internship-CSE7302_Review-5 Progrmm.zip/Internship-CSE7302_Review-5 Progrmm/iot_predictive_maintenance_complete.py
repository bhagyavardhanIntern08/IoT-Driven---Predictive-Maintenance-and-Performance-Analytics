"""
================================================================================
PROJECT   : IoT-Driven Predictive Maintenance Analytics
            for Security Automation Systems
FILE      : iot_predictive_maintenance_complete.py
SECTION   : 6.3  Software Code  (Complete Python Program)
PYTHON    : 3.10+

DESCRIPTION
-----------
This single-file program is the complete, self-contained implementation of
the IoT-Driven Predictive Maintenance Analytics system for Security Automation
Systems. It integrates six fully functional software modules:

  MODULE 1 – DataStore          : Thread-safe in-memory telemetry & alert store
  MODULE 2 – DeviceSimulator    : Realistic multi-sensor IoT device fleet sim
  MODULE 3 – DataPreprocessor   : Rolling-window feature engineering pipeline
  MODULE 4 – PredictiveEngine   : IsolationForest + GradientBoosting + RandomForest
  MODULE 5 – AlertManager       : Maintenance alert lifecycle management
  MODULE 6 – DashboardAPI       : Flask REST API for dashboard consumers
  MODULE 7 – SystemOrchestrator : End-to-end pipeline coordinator

DEPENDENCIES
------------
  pip install scikit-learn numpy flask

USAGE
-----
  python iot_predictive_maintenance_complete.py

  After startup, REST API is available at http://localhost:5050
    GET  /api/v1/health            – system health check
    GET  /api/v1/devices           – all registered devices
    GET  /api/v1/health-summary    – device health leaderboard
    GET  /api/v1/alerts            – active maintenance alerts
    GET  /api/v1/alerts/all        – all alerts including resolved
    GET  /api/v1/stats             – system statistics
    POST /api/v1/alerts/<id>/acknowledge
    POST /api/v1/alerts/<id>/resolve
================================================================================
"""

# ─────────────────────────────────────────────────────────────────────────────
# Standard library imports
# ─────────────────────────────────────────────────────────────────────────────
import logging
import math
import random
import sys
import threading
import time
import warnings
from collections import defaultdict, deque
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

# ─────────────────────────────────────────────────────────────────────────────
# Third-party imports
# ─────────────────────────────────────────────────────────────────────────────
import numpy as np
from flask import Flask, abort, jsonify, request
from sklearn.ensemble import (
    GradientBoostingClassifier,
    IsolationForest,
    RandomForestClassifier,
)
from sklearn.linear_model import LinearRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────────────────────────────────────
# Logging configuration
# ─────────────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)-24s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("iot_maintenance.log", mode="w"),
    ],
)

# Silence Flask request logs to reduce console noise
logging.getLogger("werkzeug").setLevel(logging.ERROR)


# ═════════════════════════════════════════════════════════════════════════════
# MODULE 1 – DataStore
# ═════════════════════════════════════════════════════════════════════════════

class DataStore:
    """
    Thread-safe, in-memory store for sensor telemetry, device health scores,
    and maintenance alerts.

    In production this is backed by:
      - Apache Kafka      (event streaming)
      - InfluxDB          (time-series persistence)
      - PostgreSQL        (alert and device registry)
    """

    TELEMETRY_BUFFER = 200  # maximum records per device held in memory

    def __init__(self):
        self._log = logging.getLogger("DataStore")
        self._lock = threading.Lock()
        self._telemetry: Dict[str, deque] = {}
        self._health: Dict[str, Dict[str, Any]] = {}
        self._alerts: Dict[str, Dict[str, Any]] = {}
        self._alert_counter = 0
        self._log.info("DataStore initialised (in-memory mode).")

    # ── Telemetry ─────────────────────────────────────────────────────────

    def push_telemetry(self, record: Dict[str, Any]) -> None:
        """Append one telemetry record for a device."""
        device_id = record.get("device_id", "unknown")
        with self._lock:
            if device_id not in self._telemetry:
                self._telemetry[device_id] = deque(maxlen=self.TELEMETRY_BUFFER)
            self._telemetry[device_id].append(record)

    def get_latest_telemetry(self, max_records: int = 100) -> List[Dict[str, Any]]:
        """Return the most recent record for every registered device."""
        with self._lock:
            rows = [list(buf)[-1] for buf in self._telemetry.values() if buf]
        return rows[:max_records]

    def get_device_history(self, device_id: str, last_n: int = 50) -> List[Dict[str, Any]]:
        """Return the last last_n records for a specific device."""
        with self._lock:
            buf = self._telemetry.get(device_id, deque())
            return list(buf)[-last_n:]

    def get_registered_devices(self) -> List[str]:
        """All device IDs that have pushed at least one telemetry record."""
        with self._lock:
            return list(self._telemetry.keys())

    # ── Health snapshots ──────────────────────────────────────────────────

    def update_device_health(
        self,
        device_id: str,
        health_score: float,
        fault_probability: float,
        rul_days: float,
        severity: str,
    ) -> None:
        """Overwrite (upsert) the health snapshot for a device."""
        with self._lock:
            self._health[device_id] = {
                "device_id":        device_id,
                "health_score":     round(health_score, 2),
                "fault_probability": round(fault_probability, 4),
                "rul_days":         round(rul_days, 1),
                "severity":         severity,
                "updated_at":       datetime.utcnow().isoformat() + "Z",
            }

    def get_device_health(self, device_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            return self._health.get(device_id)

    def get_health_summary(self) -> List[Dict[str, Any]]:
        """All health snapshots sorted by health score ascending (worst first)."""
        with self._lock:
            rows = list(self._health.values())
        return sorted(rows, key=lambda r: r["health_score"])

    # ── Alerts ────────────────────────────────────────────────────────────

    def add_alert(self, alert: Dict[str, Any]) -> str:
        """Persist a new alert and return its auto-generated alert_id."""
        with self._lock:
            self._alert_counter += 1
            alert_id = f"ALT-{self._alert_counter:06d}"
            alert["alert_id"]   = alert_id
            alert["status"]     = "OPEN"
            alert["created_at"] = datetime.utcnow().isoformat() + "Z"
            self._alerts[alert_id] = alert
        return alert_id

    def acknowledge_alert(self, alert_id: str) -> bool:
        with self._lock:
            if alert_id in self._alerts:
                self._alerts[alert_id]["status"]           = "ACKNOWLEDGED"
                self._alerts[alert_id]["acknowledged_at"]  = datetime.utcnow().isoformat() + "Z"
                return True
        return False

    def resolve_alert(self, alert_id: str) -> bool:
        with self._lock:
            if alert_id in self._alerts:
                self._alerts[alert_id]["status"]      = "RESOLVED"
                self._alerts[alert_id]["resolved_at"] = datetime.utcnow().isoformat() + "Z"
                return True
        return False

    def get_active_alerts(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [a for a in self._alerts.values() if a["status"] in ("OPEN", "ACKNOWLEDGED")]

    def get_all_alerts(self) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._alerts.values())

    # ── Statistics ────────────────────────────────────────────────────────

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            total_records = sum(len(b) for b in self._telemetry.values())
            return {
                "registered_devices":     len(self._telemetry),
                "total_telemetry_records": total_records,
                "health_snapshots":        len(self._health),
                "total_alerts":            len(self._alerts),
                "active_alerts":           sum(
                    1 for a in self._alerts.values()
                    if a["status"] in ("OPEN", "ACKNOWLEDGED")
                ),
            }


# ═════════════════════════════════════════════════════════════════════════════
# MODULE 2 – Device Simulator
# ═════════════════════════════════════════════════════════════════════════════

# Nominal sensor values, Gaussian noise standard deviations, and fault offsets
# for each of the five security automation device types.
DEVICE_PROFILES: Dict[str, Dict] = {
    "PTZ_CAMERA": {
        "sensors":     ["vibration_rms_g", "motor_temp_c", "motor_current_a", "pan_angle_deg"],
        "nominal":     {"vibration_rms_g": 0.12, "motor_temp_c": 42.0,
                        "motor_current_a": 0.45, "pan_angle_deg": 0.0},
        "noise_std":   {"vibration_rms_g": 0.02, "motor_temp_c": 1.5,
                        "motor_current_a": 0.03, "pan_angle_deg": 5.0},
        "fault_delta": {"vibration_rms_g": 1.20, "motor_temp_c": 28.0,
                        "motor_current_a": 0.60, "pan_angle_deg": 0.0},
    },
    "ACCESS_CONTROL": {
        "sensors":     ["lock_current_a", "lock_temp_c", "door_open_count", "battery_voltage_v"],
        "nominal":     {"lock_current_a": 0.30, "lock_temp_c": 35.0,
                        "door_open_count": 0,   "battery_voltage_v": 12.6},
        "noise_std":   {"lock_current_a": 0.02, "lock_temp_c": 1.0,
                        "door_open_count": 0,   "battery_voltage_v": 0.05},
        "fault_delta": {"lock_current_a": 0.50, "lock_temp_c": 20.0,
                        "door_open_count": 0,   "battery_voltage_v": -2.5},
    },
    "ALARM_PANEL": {
        "sensors":     ["supply_voltage_v", "panel_temp_c", "siren_current_a", "tamper_events"],
        "nominal":     {"supply_voltage_v": 13.8, "panel_temp_c": 38.0,
                        "siren_current_a": 0.00, "tamper_events": 0},
        "noise_std":   {"supply_voltage_v": 0.10, "panel_temp_c": 1.2,
                        "siren_current_a": 0.005, "tamper_events": 0},
        "fault_delta": {"supply_voltage_v": -2.0, "panel_temp_c": 22.0,
                        "siren_current_a": 0.0,  "tamper_events": 0},
    },
    "MOTION_DETECTOR": {
        "sensors":     ["signal_quality_pct", "detector_temp_c", "false_trigger_count", "rssi_dbm"],
        "nominal":     {"signal_quality_pct": 92.0, "detector_temp_c": 33.0,
                        "false_trigger_count": 0,   "rssi_dbm": -55.0},
        "noise_std":   {"signal_quality_pct": 2.0,  "detector_temp_c": 0.8,
                        "false_trigger_count": 0,   "rssi_dbm": 3.0},
        "fault_delta": {"signal_quality_pct": -45.0, "detector_temp_c": 12.0,
                        "false_trigger_count": 3,   "rssi_dbm": -20.0},
    },
    "PERIMETER_SENSOR": {
        "sensors":     ["vibration_rms_g", "enclosure_humidity_pct", "sensor_temp_c", "battery_pct"],
        "nominal":     {"vibration_rms_g": 0.05, "enclosure_humidity_pct": 55.0,
                        "sensor_temp_c": 28.0,   "battery_pct": 88.0},
        "noise_std":   {"vibration_rms_g": 0.01, "enclosure_humidity_pct": 3.0,
                        "sensor_temp_c": 2.0,    "battery_pct": 0.1},
        "fault_delta": {"vibration_rms_g": 0.80, "enclosure_humidity_pct": 30.0,
                        "sensor_temp_c": 0.0,    "battery_pct": -0.05},
    },
}

DEVICE_TYPE_KEYS = list(DEVICE_PROFILES.keys())


class SimulationConfig:
    """Configuration parameters for the device simulation."""
    def __init__(
        self,
        num_devices: int = 10,
        sampling_interval: float = 2.0,
        fault_injection_probability: float = 0.20,
    ):
        self.num_devices = num_devices
        self.sampling_interval = sampling_interval
        self.fault_injection_probability = fault_injection_probability


class SimulatedDevice:
    """
    One simulated security automation device.
    Produces multi-sensor telemetry with optional progressive fault injection
    following a sigmoidal degradation model.
    """

    def __init__(self, device_id: str, device_type: str, inject_fault: bool = False):
        self.device_id    = device_id
        self.device_type  = device_type
        self.profile      = DEVICE_PROFILES[device_type]
        self.inject_fault = inject_fault
        self.degradation  = 0.0
        self._cycle       = 0

    def _advance_degradation(self) -> None:
        if not self.inject_fault:
            return
        rate = 0.008 + 0.012 * self.degradation
        self.degradation = min(1.0, self.degradation + random.gauss(rate, 0.002))

    def sample(self) -> Dict[str, Any]:
        """Return one telemetry record dict."""
        self._cycle += 1
        self._advance_degradation()

        nominal     = self.profile["nominal"]
        noise_std   = self.profile["noise_std"]
        fault_delta = self.profile["fault_delta"]

        record: Dict[str, Any] = {
            "device_id":       self.device_id,
            "device_type":     self.device_type,
            "timestamp":       datetime.now(timezone.utc).isoformat(),
            "cycle":           self._cycle,
            "degradation_idx": round(self.degradation, 4),
        }

        for sensor, base in nominal.items():
            noise = random.gauss(0.0, noise_std[sensor])
            value = base + noise + fault_delta[sensor] * self.degradation

            if "pct" in sensor or "quality" in sensor:
                value = max(0.0, min(100.0, value))

            if sensor in ("door_open_count", "tamper_events", "false_trigger_count"):
                value = int(random.random() < (0.05 + self.degradation * 0.50))

            record[sensor] = round(float(value), 4)

        return record


class DeviceSimulator:
    """
    Manages a fleet of SimulatedDevice objects, samples them periodically,
    and pushes telemetry records into the DataStore.
    """

    def __init__(self, config: SimulationConfig, store: DataStore):
        self._log    = logging.getLogger("DeviceSimulator")
        self.config  = config
        self.store   = store
        self._running = False

        self.devices: List[SimulatedDevice] = []
        for i in range(config.num_devices):
            dtype  = DEVICE_TYPE_KEYS[i % len(DEVICE_TYPE_KEYS)]
            inject = random.random() < config.fault_injection_probability
            dev_id = f"{dtype[:3].upper()}-{(i + 1):03d}"
            self.devices.append(SimulatedDevice(dev_id, dtype, inject_fault=inject))

        faulty = [d.device_id for d in self.devices if d.inject_fault]
        self._log.info(
            f"Fleet: {len(self.devices)} devices | "
            f"Fault-injected: {faulty if faulty else 'None'}"
        )

    def run(self) -> None:
        self._running = True
        self._log.info("DeviceSimulator started.")
        while self._running:
            for device in self.devices:
                self.store.push_telemetry(device.sample())
            time.sleep(self.config.sampling_interval)
        self._log.info("DeviceSimulator stopped.")

    def stop(self) -> None:
        self._running = False


# ═════════════════════════════════════════════════════════════════════════════
# MODULE 3 – Data Preprocessor
# ═════════════════════════════════════════════════════════════════════════════

# Min/max bounds for per-sensor min-max normalisation to [0, 1]
SENSOR_BOUNDS: Dict[str, tuple] = {
    "vibration_rms_g":        (0.00, 2.00),
    "motor_temp_c":           (20.0, 90.0),
    "motor_current_a":        (0.00, 1.50),
    "pan_angle_deg":          (-180, 180.),
    "lock_current_a":         (0.00, 1.00),
    "lock_temp_c":            (20.0, 80.0),
    "door_open_count":        (0.00, 10.0),
    "battery_voltage_v":      (9.00, 14.0),
    "supply_voltage_v":       (10.0, 15.0),
    "panel_temp_c":           (20.0, 80.0),
    "siren_current_a":        (0.00, 2.00),
    "tamper_events":          (0.00, 5.00),
    "signal_quality_pct":     (0.00, 100.),
    "detector_temp_c":        (20.0, 70.0),
    "false_trigger_count":    (0.00, 10.0),
    "rssi_dbm":               (-100., -30.),
    "enclosure_humidity_pct": (10.0, 100.),
    "sensor_temp_c":          (-10., 70.0),
    "battery_pct":            (0.00, 100.),
}

# Sensor name mappings per device type → feature slot role
DEVICE_SENSOR_MAP: Dict[str, Dict[str, str]] = {
    "PTZ_CAMERA":      {"primary": "vibration_rms_g",   "temp": "motor_temp_c",
                        "current": "motor_current_a",   "secondary": "motor_current_a"},
    "ACCESS_CONTROL":  {"primary": "lock_current_a",    "temp": "lock_temp_c",
                        "current": "battery_voltage_v", "secondary": "battery_voltage_v",
                        "event":   "door_open_count"},
    "ALARM_PANEL":     {"primary": "supply_voltage_v",  "temp": "panel_temp_c",
                        "current": "siren_current_a",   "secondary": "supply_voltage_v",
                        "event":   "tamper_events"},
    "MOTION_DETECTOR": {"primary": "signal_quality_pct","temp": "detector_temp_c",
                        "current": "rssi_dbm",          "secondary": "rssi_dbm",
                        "event":   "false_trigger_count"},
    "PERIMETER_SENSOR":{"primary": "vibration_rms_g",  "temp": "sensor_temp_c",
                        "current": "battery_pct",       "secondary": "enclosure_humidity_pct"},
}

FEATURE_LENGTH = 16


class DataPreprocessor:
    """
    Transforms raw telemetry dicts into fixed-length (16) numpy float32
    feature vectors using per-device rolling statistical windows.

    Feature vector layout:
      [0-3]   primary sensor: mean, std, max, min
      [4-7]   temperature:    mean, std, max, min
      [8-9]   current/voltage:mean, std
      [10-11] secondary:      mean, std
      [12]    degradation_idx (raw)
      [13]    cycle normalised to [0,1]
      [14]    event rate (discrete event normalised)
      [15]    sensor drift (rolling std of primary)
    """

    def __init__(self, window_size: int = 10):
        self._log = logging.getLogger("DataPreprocessor")
        self.window_size = window_size
        self._buffers: Dict[str, Dict[str, deque]] = defaultdict(
            lambda: defaultdict(lambda: deque(maxlen=window_size))
        )
        self._cycle_max = 10_000
        self._log.info(f"DataPreprocessor initialised | window_size={window_size}")

    # ── Public API ────────────────────────────────────────────────────────

    def transform(self, record: Dict[str, Any]) -> Optional[np.ndarray]:
        """
        Transform a raw telemetry record into a feature vector.
        Returns None if the record is invalid or window is not yet full enough.
        """
        if not self._validate(record):
            return None

        device_id   = record["device_id"]
        device_type = record["device_type"]

        # Normalise and buffer each sensor reading
        for sensor, (lo, hi) in SENSOR_BOUNDS.items():
            if sensor in record:
                self._buffers[device_id][sensor].append(
                    self._norm(record[sensor], lo, hi)
                )

        # Require minimum history
        smap    = DEVICE_SENSOR_MAP.get(device_type, {})
        primary = smap.get("primary", "vibration_rms_g")
        if len(self._buffers[device_id][primary]) < max(3, self.window_size // 2):
            return None

        return self._build_vector(record, device_type)

    # ── Internal helpers ──────────────────────────────────────────────────

    @staticmethod
    def _validate(record: Dict[str, Any]) -> bool:
        required = {"device_id", "device_type", "timestamp", "cycle"}
        return required.issubset(record.keys()) and isinstance(record["device_id"], str)

    @staticmethod
    def _norm(value: float, lo: float, hi: float) -> float:
        return max(0.0, min(1.0, (value - lo) / (hi - lo))) if hi != lo else 0.0

    def _stats(self, buf: deque) -> Dict[str, float]:
        if not buf:
            return {"mean": 0.0, "std": 0.0, "max": 0.0, "min": 0.0}
        a = list(buf)
        return {"mean": float(np.mean(a)), "std": float(np.std(a)),
                "max": float(np.max(a)),  "min": float(np.min(a))}

    def _build_vector(self, record: Dict[str, Any], device_type: str) -> np.ndarray:
        did  = record["device_id"]
        smap = DEVICE_SENSOR_MAP.get(device_type, {})
        bufs = self._buffers[did]

        ps = self._stats(bufs.get(smap.get("primary",    "vibration_rms_g"), deque()))
        ts = self._stats(bufs.get(smap.get("temp",       "motor_temp_c"),    deque()))
        cs = self._stats(bufs.get(smap.get("current",    "motor_current_a"), deque()))
        ss = self._stats(bufs.get(smap.get("secondary",  smap.get("current", "motor_current_a")), deque()))

        primary_buf = bufs.get(smap.get("primary", "vibration_rms_g"), deque())
        drift       = float(np.std(list(primary_buf))) if len(primary_buf) > 1 else 0.0

        event_sensor = smap.get("event")
        event_rate   = (float(np.mean(list(bufs[event_sensor])))
                        if event_sensor and bufs.get(event_sensor) else 0.0)

        vec = np.array([
            ps["mean"], ps["std"], ps["max"], ps["min"],
            ts["mean"], ts["std"], ts["max"], ts["min"],
            cs["mean"], cs["std"],
            ss["mean"], ss["std"],
            float(record.get("degradation_idx", 0.0)),
            self._norm(float(record.get("cycle", 0)), 0, self._cycle_max),
            event_rate,
            drift,
        ], dtype=np.float32)

        return vec


# ═════════════════════════════════════════════════════════════════════════════
# MODULE 4 – ML Predictive Maintenance Engine
# ═════════════════════════════════════════════════════════════════════════════

FAULT_CLASSES: List[str] = [
    "NORMAL",
    "BEARING_WEAR",
    "THERMAL_DEGRADATION",
    "POWER_SUPPLY_FAULT",
    "SENSOR_DRIFT",
    "MECHANICAL_IMBALANCE",
]

SEVERITY_THRESHOLDS = [
    (0.95, "CRITICAL"),
    (0.85, "HIGH"),
    (0.70, "MEDIUM"),
    (0.50, "LOW"),
    (0.00, "NORMAL"),
]

MAX_RUL_DAYS = 365.0


class SyntheticDataGenerator:
    """
    Generates physics-informed synthetic labelled training data.
    Each fault class shifts characteristic sensor features in ways
    consistent with domain knowledge of security system failure modes.
    """

    def __init__(self, n_per_class: int = 600, random_state: int = 42):
        self.n_per_class  = n_per_class
        self.rng          = np.random.default_rng(random_state)

    def generate(self):
        X_parts, y_parts = [], []
        for idx, _ in enumerate(FAULT_CLASSES):
            X_parts.append(self._class_samples(idx))
            y_parts.append(np.full(self.n_per_class, idx, dtype=int))
        X = np.vstack(X_parts).astype(np.float32)
        y = np.concatenate(y_parts)
        return X, y

    def _class_samples(self, class_idx: int) -> np.ndarray:
        n   = self.n_per_class
        rng = self.rng
        X   = rng.uniform(0.05, 0.25, size=(n, FEATURE_LENGTH)).astype(np.float32)

        if class_idx == 0:      # NORMAL
            X[:, 12] = rng.uniform(0.00, 0.10, n)
            X[:, 13] = rng.uniform(0.00, 0.50, n)

        elif class_idx == 1:    # BEARING_WEAR
            X[:, 0]  = rng.uniform(0.45, 0.95, n)
            X[:, 2]  = rng.uniform(0.60, 1.00, n)
            X[:, 1]  = rng.uniform(0.08, 0.20, n)
            X[:, 4]  = rng.uniform(0.30, 0.60, n)
            X[:, 12] = rng.uniform(0.40, 0.90, n)
            X[:, 15] = rng.uniform(0.10, 0.40, n)

        elif class_idx == 2:    # THERMAL_DEGRADATION
            X[:, 4]  = rng.uniform(0.65, 1.00, n)
            X[:, 6]  = rng.uniform(0.80, 1.00, n)
            X[:, 5]  = rng.uniform(0.05, 0.15, n)
            X[:, 8]  = rng.uniform(0.40, 0.75, n)
            X[:, 12] = rng.uniform(0.35, 0.85, n)

        elif class_idx == 3:    # POWER_SUPPLY_FAULT
            X[:, 8]  = rng.uniform(0.60, 0.95, n)
            X[:, 9]  = rng.uniform(0.10, 0.25, n)
            X[:, 10] = rng.uniform(0.05, 0.30, n)
            X[:, 11] = rng.uniform(0.08, 0.20, n)
            X[:, 12] = rng.uniform(0.30, 0.80, n)

        elif class_idx == 4:    # SENSOR_DRIFT
            X[:, 0]  = rng.uniform(0.60, 1.00, n)
            X[:, 1]  = rng.uniform(0.12, 0.30, n)
            X[:, 15] = rng.uniform(0.20, 0.50, n)
            X[:, 14] = rng.uniform(0.15, 0.50, n)
            X[:, 12] = rng.uniform(0.20, 0.70, n)

        elif class_idx == 5:    # MECHANICAL_IMBALANCE
            X[:, 0]  = rng.uniform(0.35, 0.75, n)
            X[:, 2]  = rng.uniform(0.50, 0.90, n)
            X[:, 3]  = rng.uniform(0.00, 0.10, n)
            X[:, 4]  = rng.uniform(0.35, 0.65, n)
            X[:, 12] = rng.uniform(0.30, 0.80, n)
            X[:, 15] = rng.uniform(0.12, 0.35, n)

        # Add small Gaussian noise to all features
        X += rng.normal(0, 0.02, size=X.shape).astype(np.float32)
        return np.clip(X, 0.0, 1.0)


class PredictiveMaintenanceEngine:
    """
    Three-model ML ensemble for predictive maintenance scoring:
      1. IsolationForest          – unsupervised anomaly detection
      2. GradientBoostingClassifier – binary fault probability estimation
      3. RandomForestClassifier   – multi-class fault type identification
    Plus a LinearRegression RUL estimator.
    """

    def __init__(self, contamination: float = 0.12, random_state: int = 42):
        self._log           = logging.getLogger("MLEngine")
        self._trained       = False
        self._contamination = contamination
        self._rs            = random_state
        self._iso_forest    = None
        self._gb_pipe       = None
        self._rf_pipe       = None
        self._rul_model     = None
        self._rul_scaler    = StandardScaler()

    # ── Training ──────────────────────────────────────────────────────────

    def train(self) -> None:
        """Generate synthetic data and fit all models."""
        self._log.info("Generating synthetic training data …")
        gen = SyntheticDataGenerator(n_per_class=600, random_state=self._rs)
        X, y = gen.generate()

        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y, test_size=0.20, stratify=y, random_state=self._rs
        )
        self._log.info(
            f"Train: {X_tr.shape[0]} | Test: {X_te.shape[0]} | Features: {X_tr.shape[1]}"
        )

        # 1. IsolationForest – trained only on NORMAL samples
        self._iso_forest = IsolationForest(
            n_estimators=150, contamination=self._contamination,
            random_state=self._rs, n_jobs=-1,
        )
        self._iso_forest.fit(X_tr[y_tr == 0])
        self._log.info("IsolationForest fitted.")

        # 2. Gradient Boosting – binary fault vs. normal
        y_bin_tr = (y_tr != 0).astype(int)
        y_bin_te = (y_te != 0).astype(int)
        self._gb_pipe = Pipeline([
            ("sc",  StandardScaler()),
            ("clf", GradientBoostingClassifier(
                n_estimators=200, max_depth=4, learning_rate=0.08,
                subsample=0.85, random_state=self._rs,
            )),
        ])
        self._gb_pipe.fit(X_tr, y_bin_tr)
        self._log.info(
            f"GradientBoosting accuracy: {self._gb_pipe.score(X_te, y_bin_te):.4f}"
        )

        # 3. RandomForest – multi-class fault type
        self._rf_pipe = Pipeline([
            ("sc",  StandardScaler()),
            ("clf", RandomForestClassifier(
                n_estimators=200, max_depth=12, class_weight="balanced",
                random_state=self._rs, n_jobs=-1,
            )),
        ])
        self._rf_pipe.fit(X_tr, y_tr)
        rf_acc = self._rf_pipe.score(X_te, y_te)
        self._log.info(f"RandomForest accuracy: {rf_acc:.4f}")
        report = classification_report(
            y_te, self._rf_pipe.predict(X_te),
            target_names=FAULT_CLASSES, zero_division=0
        )
        self._log.info(f"Classification Report:\n{report}")

        # 4. RUL regression
        deg   = X_tr[:, 12].reshape(-1, 1)
        rul   = np.clip(MAX_RUL_DAYS * (1.0 - deg.ravel())
                        + np.random.default_rng(self._rs).normal(0, 5, len(deg)), 0, MAX_RUL_DAYS)
        self._rul_model = LinearRegression()
        self._rul_model.fit(self._rul_scaler.fit_transform(deg), rul)
        self._log.info("RUL regression model fitted.")

        self._trained = True
        self._log.info("All models trained successfully ✓")

    # ── Inference ─────────────────────────────────────────────────────────

    def score(self, features: np.ndarray) -> Dict[str, Any]:
        """
        Score a single 16-element feature vector.

        Returns dict: health_score, fault_probability, is_fault,
                       severity, fault_type, rul_days, anomaly_score
        """
        if not self._trained:
            raise RuntimeError("Call train() before score().")

        x = features.reshape(1, -1)

        # Anomaly score: map IsolationForest decision_function to [0,1]
        raw_if   = float(self._iso_forest.decision_function(x)[0])
        iso_norm = float(np.clip((raw_if + 0.3) / 0.6, 0.0, 1.0))  # 1 = normal

        # Fault probability from GradientBoosting
        gb_prob  = float(self._gb_pipe.predict_proba(x)[0][1])

        # Blended fault probability
        fp = float(np.clip(0.65 * gb_prob + 0.35 * (1.0 - iso_norm), 0.0, 1.0))

        health_score = float(np.clip((1.0 - fp) * 100.0, 0.0, 100.0))

        severity = "NORMAL"
        for thresh, label in SEVERITY_THRESHOLDS:
            if fp >= thresh:
                severity = label
                break

        is_fault = fp >= 0.50

        if is_fault:
            class_idx  = int(self._rf_pipe.predict(x)[0])
            fault_type = FAULT_CLASSES[class_idx] if class_idx != 0 else FAULT_CLASSES[1]
        else:
            fault_type = "NORMAL"

        deg      = float(features[12])
        rul_raw  = float(self._rul_model.predict(self._rul_scaler.transform([[deg]]))[0])
        rul_days = float(np.clip(rul_raw, 0.0, MAX_RUL_DAYS))

        return {
            "health_score":      round(health_score, 2),
            "fault_probability": round(fp, 4),
            "is_fault":          is_fault,
            "severity":          severity,
            "fault_type":        fault_type,
            "rul_days":          round(rul_days, 1),
            "anomaly_score":     round(raw_if, 4),
        }


# ═════════════════════════════════════════════════════════════════════════════
# MODULE 5 – Alert Manager
# ═════════════════════════════════════════════════════════════════════════════

COOLDOWN_SECONDS: Dict[str, int] = {
    "CRITICAL": 60, "HIGH": 120, "MEDIUM": 300, "LOW": 600, "NORMAL": 3600,
}

MAINTENANCE_ACTIONS: Dict[str, Dict[str, str]] = {
    "BEARING_WEAR": {
        "short":    "Inspect and replace drive bearings.",
        "detailed": (
            "1. Isolate device and de-energise. "
            "2. Remove motor housing; inspect bearings for pitting/spalling. "
            "3. Replace bearings with OEM parts. "
            "4. Re-grease to torque specification. "
            "5. Run 30-minute test; confirm vibration < 0.15 g RMS."
        ),
    },
    "THERMAL_DEGRADATION": {
        "short":    "Clean heat sinks; inspect cooling fans and vents.",
        "detailed": (
            "1. Power down device safely. "
            "2. Clean all vents and heat sinks with compressed air. "
            "3. Replace thermal interface material. "
            "4. Verify ambient cabinet temperature within operating range. "
            "5. Confirm temp drops to nominal within 10 min of restart."
        ),
    },
    "POWER_SUPPLY_FAULT": {
        "short":    "Test and replace power supply unit or capacitors.",
        "detailed": (
            "1. Measure all PSU output rails with calibrated multimeter. "
            "2. If deviation > 5%, replace PSU with approved spare. "
            "3. Inspect capacitors for bulging or leakage and replace. "
            "4. Verify battery backup holds charge correctly."
        ),
    },
    "SENSOR_DRIFT": {
        "short":    "Recalibrate or replace degraded sensor.",
        "detailed": (
            "1. Measure against calibrated reference instrument. "
            "2. If offset > 2 sigma, recalibrate via device software. "
            "3. If calibration fails, replace sensor module. "
            "4. Monitor 48 hours post-calibration for stability."
        ),
    },
    "MECHANICAL_IMBALANCE": {
        "short":    "Re-balance rotating assembly; check for loose fasteners.",
        "detailed": (
            "1. Inspect all rotating component fasteners for tightness. "
            "2. Check for debris in motor housing. "
            "3. Perform dynamic balancing with portable balancing kit. "
            "4. Re-align motor coupling if misalignment detected."
        ),
    },
    "NORMAL": {
        "short":    "No action required. Continue monitoring.",
        "detailed": "Schedule routine inspection at next maintenance window.",
    },
}

SEVERITY_ICONS = {
    "CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🟢", "NORMAL": "⚪"
}


class AlertManager:
    """
    Generates and manages maintenance alerts for the predictive maintenance
    platform. Implements cool-down suppression to prevent alert flooding.
    """

    def __init__(self, store: DataStore):
        self._log  = logging.getLogger("AlertManager")
        self.store = store
        self._last_alert_time: Dict[str, float] = {}
        self._log.info("AlertManager initialised.")

    def raise_alert(
        self,
        device_id: str,
        fault_type: str,
        severity: str,
        fault_probability: float,
        rul_days: float,
        telemetry_snapshot: Dict[str, Any],
    ) -> Optional[str]:
        """Raise a maintenance alert if not suppressed by cool-down."""
        cooldown = COOLDOWN_SECONDS.get(severity, 300)
        elapsed  = time.time() - self._last_alert_time.get(device_id, 0.0)
        if elapsed < cooldown:
            return None

        action  = MAINTENANCE_ACTIONS.get(fault_type, MAINTENANCE_ACTIONS["NORMAL"])
        alert   = {
            "device_id":          device_id,
            "device_type":        telemetry_snapshot.get("device_type", "UNKNOWN"),
            "fault_type":         fault_type,
            "severity":           severity,
            "fault_probability":  round(fault_probability, 4),
            "rul_days":           round(rul_days, 1),
            "recommended_action": action["short"],
            "detailed_procedure": action["detailed"],
            "telemetry_snapshot": {
                k: v for k, v in telemetry_snapshot.items()
                if k != "detailed_procedure"
            },
        }

        alert_id = self.store.add_alert(alert)
        self._last_alert_time[device_id] = time.time()

        icon = SEVERITY_ICONS.get(severity, "⚪")
        self._log.warning(
            f"{icon} ALERT [{alert_id}] | {device_id} | {fault_type} | "
            f"{severity} | prob={fault_probability:.2%} | RUL={rul_days:.1f}d | "
            f"→ {action['short']}"
        )
        return alert_id

    def acknowledge(self, alert_id: str) -> bool:
        result = self.store.acknowledge_alert(alert_id)
        if result:
            self._log.info(f"Alert {alert_id} acknowledged.")
        return result

    def resolve(self, alert_id: str) -> bool:
        result = self.store.resolve_alert(alert_id)
        if result:
            self._log.info(f"Alert {alert_id} resolved.")
        return result


# ═════════════════════════════════════════════════════════════════════════════
# MODULE 6 – Dashboard REST API
# ═════════════════════════════════════════════════════════════════════════════

class DashboardAPI:
    """
    Lightweight Flask REST API exposing predictive maintenance data.

    Endpoints
    ---------
    GET  /api/v1/health
    GET  /api/v1/devices
    GET  /api/v1/devices/<device_id>?last_n=20
    GET  /api/v1/health-summary
    GET  /api/v1/alerts
    GET  /api/v1/alerts/all
    POST /api/v1/alerts/<alert_id>/acknowledge
    POST /api/v1/alerts/<alert_id>/resolve
    GET  /api/v1/stats
    """

    def __init__(self, store: DataStore, port: int = 5050):
        self._log  = logging.getLogger("DashboardAPI")
        self.store = store
        self.port  = port
        self.app   = Flask(__name__)
        self._register_routes()

    def _register_routes(self) -> None:
        store = self.store

        @self.app.route("/api/v1/health")
        def api_health():
            return jsonify({"status": "ok", "service": "IoT PdM Analytics API",
                            "version": "1.0.0",
                            "timestamp": datetime.utcnow().isoformat() + "Z"})

        @self.app.route("/api/v1/devices")
        def api_devices():
            devices = store.get_registered_devices()
            return jsonify({"count": len(devices), "devices": devices})

        @self.app.route("/api/v1/devices/<string:device_id>")
        def api_device(device_id):
            last_n  = max(1, min(request.args.get("last_n", 20, type=int), 200))
            history = store.get_device_history(device_id, last_n=last_n)
            if not history:
                abort(404, description=f"Device '{device_id}' not found.")
            return jsonify({"device_id": device_id,
                            "health":    store.get_device_health(device_id),
                            "history":   history})

        @self.app.route("/api/v1/health-summary")
        def api_health_summary():
            summary = store.get_health_summary()
            return jsonify({
                "total":     len(summary),
                "critical":  sum(1 for d in summary if d["severity"] == "CRITICAL"),
                "high":      sum(1 for d in summary if d["severity"] == "HIGH"),
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "devices":   summary,
            })

        @self.app.route("/api/v1/alerts")
        def api_active_alerts():
            alerts = store.get_active_alerts()
            return jsonify({"count": len(alerts),
                            "alerts": sorted(alerts,
                                             key=lambda a: a.get("created_at", ""),
                                             reverse=True)})

        @self.app.route("/api/v1/alerts/all")
        def api_all_alerts():
            alerts = store.get_all_alerts()
            return jsonify({"count": len(alerts),
                            "alerts": sorted(alerts,
                                             key=lambda a: a.get("created_at", ""),
                                             reverse=True)})

        @self.app.route("/api/v1/alerts/<string:alert_id>/acknowledge", methods=["POST"])
        def api_ack(alert_id):
            if not store.acknowledge_alert(alert_id):
                abort(404, description=f"Alert '{alert_id}' not found.")
            return jsonify({"alert_id": alert_id, "status": "ACKNOWLEDGED"})

        @self.app.route("/api/v1/alerts/<string:alert_id>/resolve", methods=["POST"])
        def api_resolve(alert_id):
            if not store.resolve_alert(alert_id):
                abort(404, description=f"Alert '{alert_id}' not found.")
            return jsonify({"alert_id": alert_id, "status": "RESOLVED"})

        @self.app.route("/api/v1/stats")
        def api_stats():
            return jsonify({**store.stats(),
                            "timestamp": datetime.utcnow().isoformat() + "Z"})

        @self.app.errorhandler(404)
        def not_found(err):
            return jsonify({"error": "Not Found", "message": str(err)}), 404

    def run(self) -> None:
        self._log.info(f"Dashboard REST API → http://localhost:{self.port}/api/v1/health")
        self.app.run(host="0.0.0.0", port=self.port, debug=False, use_reloader=False)


# ═════════════════════════════════════════════════════════════════════════════
# MODULE 7 – System Orchestrator
# ═════════════════════════════════════════════════════════════════════════════

class SystemOrchestrator:
    """
    Top-level coordinator that wires together all six subsystem modules
    and drives the end-to-end predictive maintenance analytics pipeline.

    Pipeline
    --------
    DeviceSimulator → DataStore → DataPreprocessor
        → PredictiveMaintenanceEngine → AlertManager
        ← DashboardAPI (parallel REST server)
    """

    ANALYTICS_INTERVAL_SEC = 3     # seconds between analytics cycles
    SUMMARY_EVERY_N_CYCLES = 5     # print dashboard summary every N cycles

    def __init__(
        self,
        num_devices: int = 10,
        sampling_interval: float = 2.0,
        api_port: int = 5050,
    ):
        self._log = logging.getLogger("SystemOrchestrator")
        self._log.info("=" * 72)
        self._log.info("  IoT-Driven Predictive Maintenance Analytics")
        self._log.info("  for Security Automation Systems  |  Section 6.3 – Software Code")
        self._log.info("=" * 72)

        # Shared data hub
        self.store = DataStore()

        # Subsystems
        self.simulator    = DeviceSimulator(
            config=SimulationConfig(
                num_devices=num_devices,
                sampling_interval=sampling_interval,
            ),
            store=self.store,
        )
        self.preprocessor = DataPreprocessor(window_size=8)
        self.ml_engine    = PredictiveMaintenanceEngine()
        self.alert_mgr    = AlertManager(store=self.store)
        self.api          = DashboardAPI(store=self.store, port=api_port)

        self._running = False
        self._cycle   = 0

    # ── Public API ────────────────────────────────────────────────────────

    def start(self) -> None:
        """Start all subsystems. Blocks on the analytics loop."""
        self._running = True

        # Train ML models (synchronous – must complete before ingestion)
        self._log.info("Training ML models on synthetic historical data …")
        self.ml_engine.train()

        # Start REST API in daemon thread
        threading.Thread(target=self.api.run, name="DashboardAPI", daemon=True).start()

        # Start device simulator in daemon thread
        threading.Thread(target=self.simulator.run, name="DeviceSimulator", daemon=True).start()

        self._log.info("All subsystems started. Entering analytics loop …")
        self._log.info(
            f"REST API available at http://localhost:{self.api.port}/api/v1/health"
        )

        # Analytics loop (blocks main thread)
        self._analytics_loop()

    def stop(self) -> None:
        self._running = False
        self.simulator.stop()
        self._log.info("SystemOrchestrator stopped.")

    # ── Analytics loop ────────────────────────────────────────────────────

    def _analytics_loop(self) -> None:
        while self._running:
            time.sleep(self.ANALYTICS_INTERVAL_SEC)
            self._cycle += 1
            self._log.info(
                f"── Analytics Cycle {self._cycle:04d} "
                f"({datetime.now().strftime('%H:%M:%S')}) ──────────────────"
            )

            records = self.store.get_latest_telemetry(max_records=100)
            if not records:
                self._log.debug("No telemetry buffered yet – waiting …")
                continue

            scored_count = 0
            fault_count  = 0

            for rec in records:
                features = self.preprocessor.transform(rec)
                if features is None:
                    continue

                result = self.ml_engine.score(features)
                scored_count += 1

                self.store.update_device_health(
                    device_id       = rec["device_id"],
                    health_score    = result["health_score"],
                    fault_probability = result["fault_probability"],
                    rul_days        = result["rul_days"],
                    severity        = result["severity"],
                )

                if result["is_fault"]:
                    fault_count += 1
                    self.alert_mgr.raise_alert(
                        device_id          = rec["device_id"],
                        fault_type         = result["fault_type"],
                        severity           = result["severity"],
                        fault_probability  = result["fault_probability"],
                        rul_days           = result["rul_days"],
                        telemetry_snapshot = rec,
                    )

            self._log.info(
                f"  Scored: {scored_count} devices | "
                f"Faults detected: {fault_count} | "
                f"Active alerts: {len(self.store.get_active_alerts())}"
            )

            if self._cycle % self.SUMMARY_EVERY_N_CYCLES == 0:
                self._print_summary()

    # ── Console dashboard summary ─────────────────────────────────────────

    def _print_summary(self) -> None:
        summary = self.store.get_health_summary()
        alerts  = self.store.get_active_alerts()
        stats   = self.store.stats()

        self._log.info("╔" + "═" * 70 + "╗")
        self._log.info("║   PREDICTIVE MAINTENANCE DASHBOARD SUMMARY" + " " * 27 + "║")
        self._log.info("╠" + "═" * 70 + "╣")
        self._log.info(
            f"║  Devices:{stats['registered_devices']:>4}  |  "
            f"Telemetry Records:{stats['total_telemetry_records']:>6}  |  "
            f"Active Alerts:{len(alerts):>4}" + " " * 16 + "║"
        )
        self._log.info("╠" + "═" * 70 + "╣")

        for row in summary:
            bar   = "█" * int(row["health_score"] / 10)
            blank = "░" * (10 - int(row["health_score"] / 10))
            icon  = SEVERITY_ICONS.get(row["severity"], "⚪")
            line  = (
                f"║  {row['device_id']:<16} [{bar}{blank}] "
                f"Hlth:{row['health_score']:5.1f}%  "
                f"FP:{row['fault_probability']:.2f}  "
                f"RUL:{row['rul_days']:5.1f}d  {icon} {row['severity']:<8}"
            )
            # Pad to fixed width
            line  = line + " " * max(0, 71 - len(line)) + "║"
            self._log.info(line)

        self._log.info("╚" + "═" * 70 + "╝")


# ═════════════════════════════════════════════════════════════════════════════
# Application Entry Point
# ═════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    orchestrator = SystemOrchestrator(
        num_devices=10,
        sampling_interval=2.0,
        api_port=5050,
    )
    try:
        orchestrator.start()
    except KeyboardInterrupt:
        print("\n")
        orchestrator.stop()
